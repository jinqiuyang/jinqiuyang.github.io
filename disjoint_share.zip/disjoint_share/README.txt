This folder contains source code and runnable jar to visualize disjoint traces together. At this moment, two types of disjoint traces are supported: get/set to the same attributes and read/write to the same database tables.

This project contains three components: 
  1. webapp that uses d3 javascript library to visualize a tree structure, from which users can click a few nodes and download a subset of assessment file;
  2. server that handles requests from user input on dumping subsets of assessment files;
  3. collector that extracts disjoint tracess as .json file for webapp; Also, it is invoked by server to dump subsets of assessment files.

The structure of directory is as follows:
  - code: source code of server side and extraction of .json file, which can be imported as maven projects; 
  - runnable 
    - run.sh: a simple example to show to invoke server.jar and collector.jar
    - server.jar: a simple server to call collector.jar to dump subsets of assessment files
    - collector.jar
    - config.properties: users can specify input, trace type (attribute/database), output and subset output here, need to be modified.
    - server.properties: needed to use appscan library, need to be modified.
    - webgoat-5.3.ozasmt: the assessment file from webgoat 5.3

How to use:
  1. Modify server.properties and config.properties
    - server.properties contains some settings about connecting to appscan (e.g., 'appscan.source.install.location'
    - config.properties contains some input/output paths for collector.jar
      - output: the location of .json file generated, note that this should be the same location where 'webapp' directory is placed, in the example, 'webapp' is placed under Tomcat directory.
      - sub_output_prefix: the location of a subset of an assessment file; note that this path is used in webapp/index.html to redirect to the subset generated after user clicks on 'download' in the web interface.
      - type: now only 'attribute' and 'database' are supported.
      - assessment: the location where the input assessment file (from AppScanSource) is.
      - server_properties: the location of server.properties

  2. Run 'run.sh'
