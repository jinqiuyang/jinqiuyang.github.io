#!/bin/bash

#generate .json file for visualization
java -jar ./collector.jar config.properties 

#start server side
java -jar server.jar config.properties
